﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManjDb.DataModels
{
    public class DbContext : Microsoft.EntityFrameworkCore.DbContext
    {
        public DbSet<PhotoForm> PhotoForms { get; set; }
        public DbSet<EmergencyForm> EmergencyForms { get; set; }
        public DbSet<AnimalApprovalForm> AnimalApprovalForms { get; set; }
        public DbSet<ApprovedPickupForm> ApprovedPickupForms { get; set; }
        public DbSet<ParentInfoForm> ParentInfoForms { get; set; }
        public DbSet<ParentEmailForm> ParentEmailForms { get; set; }
        public DbSet<Child> Children { get; set; }
        public DbSet<Classroom> Classrooms { get; set; }
        public DbSet<Parent> Parents { get; set; }
        public DbSet<Program> Programs { get; set; }
        public DbSet<HealthcareProvider> HealthcareProviders { get; set; }
        public DbSet<EmergencyContact> EmergencyContacts { get; set; }
        public DbSet<EmergencyContactForm> EmergencyContactForms { get; set; }
        public DbSet<ParentDetails> ParentDetails { get; set; }
        public DbSet<StaffMember> StaffMembers { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                string connectionString = "Data Source=forms.db";
                optionsBuilder.UseSqlite(connectionString);
            }
        }
    }
}
