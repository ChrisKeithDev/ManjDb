﻿using Newtonsoft.Json;

namespace ManjDb.DataModels
{
    public class Child
    {
        [JsonProperty("id")]
        public int? ChildId { get; set; }

        [JsonProperty("first_name")]
        public string? FirstName { get; set; }

        [JsonProperty("last_name")]
        public string? LastName { get; set; }

        [JsonProperty("birth_date")]
        public DateTime? BirthDate { get; set; }

        [JsonProperty("gender")]
        public string? Gender { get; set; }

        [JsonProperty("hours_string")]
        public string? HoursString { get; set; }

        [JsonProperty("allergies")]
        public string? Allergies { get; set; }

        [JsonProperty("notes")]
        public string? Notes { get; set; }

        [JsonProperty("program")]
        public string? Program { get; set; }

        [JsonProperty("first_day")]
        public DateTime? FirstDay { get; set; }

        [JsonProperty("approved_adults_string")]
        public string? ApprovedAdultsString { get; set; }

        [JsonProperty("emergency_contacts_string")]
        public string? EmergencyContactsString { get; set; }

        [JsonProperty("classroom_ids")]
        public int[]? ClassroomIds { get; set; }

        public ICollection<Parent>? Parents { get; set; }
    }
}