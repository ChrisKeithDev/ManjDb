﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManjDb.DataModels
{
    public class FormModel<T> where T : class
    {
        [JsonProperty("form_template_id")]
        public int FormTemplateId { get; set; }

        [JsonProperty("child_id")]
        public int ChildId { get; set; }

        [JsonProperty("state")]
        public string? State { get; set; }

        [JsonProperty("created_at")]
        public DateTime? CreatedAt { get; set; }

        [JsonProperty("updated_at")]
        public DateTime? UpdatedAt { get; set; }

        [JsonProperty("classroom_id")]
        public object? ClassroomId { get; set; }

        [JsonProperty("rating")]
        public object? Rating { get; set; }

        [JsonProperty("fields")]
        public T? Fields { get; set; }

        [JsonProperty("notes")]
        public string? Notes { get; set; }
    }
    public class PhotoForm : FormModel<Dictionary<string, string>>
    {
        // No additional properties
    }

    public class EmergencyForm : FormModel<Dictionary<string, string>>
    {
        // No additional properties
    }

    public class AnimalApprovalForm : FormModel<Dictionary<string, string>>
    {
        // No additional properties
    }

    public class ApprovedPickupForm : FormModel<Dictionary<string, string>>
    {
        // No additional properties
    }

    public class ParentInfoForm : FormModel<Dictionary<string, string>>
    {
        // No additional properties
    }

    public class ParentEmailForm : FormModel<Dictionary<string, string>>
    {
        // No additional properties
    }
}
