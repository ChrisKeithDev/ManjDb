﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ManjDb.DataModels
{
    public class EmergencyContactForm
    {
        [Key]
        [JsonProperty("id")]
        public int FormId { get; set; }

        [JsonProperty("child_id")]
        public int? ChildId { get; set; }

        [JsonProperty("fields.Date")]
        public DateTime Date { get; set; }

        [JsonProperty("fields.Phone Number")]
        public string? PhoneNumber { get; set; }

        [JsonProperty("fields.Parent 1 Work #")]
        public string? Parent1WorkNumber { get; set; }

        [JsonProperty("fields.Parent 2 Work #")]
        public string? Parent2WorkNumber { get; set; }

        [JsonProperty("fields.Health Insurance")]
        public string? HealthInsurance { get; set; }

        //[JsonProperty("fields.Child's Name.last")]
        //public string? ChildLastName { get; set; }

        [JsonProperty("fields.Parent 1 Mobile #")]
        public string? Parent1MobileNumber { get; set; }

        [JsonProperty("fields.Parent 2 Mobile #")]
        public string? Parent2MobileNumber { get; set; }

        //[JsonProperty("fields.Child's Name.first")]
        //public string? ChildFirstName { get; set; }

        [JsonProperty("fields.Parent 1 Name.last")]
        public string? Parent1LastName { get; set; }

        [JsonProperty("fields.Parent 2 Name.last")]
        public string? Parent2LastName { get; set; }

        [JsonProperty("fields.Parent 1 Name.first")]
        public string? Parent1FirstName { get; set; }

        [JsonProperty("fields.Parent 2 Name.first")]
        public string? Parent2FirstName { get; set; }

        [JsonProperty("fields.Child's Address.city")]
        public string? ChildAddressCity { get; set; }

        [JsonProperty("fields.Dentist Address.city")]
        public string? DentistAddressCity { get; set; }

        [JsonProperty("fields.Dentist Phone Number")]
        public string? DentistPhoneNumber { get; set; }

        [JsonProperty("fields.Child's Address.street")]
        public string? ChildAddressStreet { get; set; }

        [JsonProperty("fields.Dentist Address.street")]
        public string? DentistAddressStreet { get; set; }

        [JsonProperty("fields.Parent 1 Email Address")]
        public string? Parent1EmailAddress { get; set; }

        [JsonProperty("fields.Parent 2 Email Address")]
        public string? Parent2EmailAddress { get; set; }

        [JsonProperty("fields.Symptoms and treatment")]
        public string? SymptomsAndTreatment { get; set; }

        [JsonProperty("fields.Child's Pediatrician.last")]
        public string? ChildPediatricianLastName { get; set; }

        [JsonProperty("fields.Emergency Contacts_1_Name")]
        public string? EmergencyContact1Name { get; set; }

        [JsonProperty("fields.Emergency Contacts_2_Name")]
        public string? EmergencyContact2Name { get; set; }

        [JsonProperty("fields.Emergency Contacts_3_Name")]
        public string? EmergencyContact3Name { get; set; }

        [JsonProperty("fields.Pediatrician Address.city")]
        public string? PediatricianAddressCity { get; set; }

        [JsonProperty("fields.Child's Pediatrician.first")]
        public string? ChildPediatricianFirstName { get; set; }

        [JsonProperty("fields.Emergency Contacts_1_Phone")]
        public string? EmergencyContact1Phone { get; set; }

        [JsonProperty("fields.Emergency Contacts_2_Phone")]
        public string? EmergencyContact2Phone { get; set; }

        [JsonProperty("fields.Emergency Contacts_3_Phone")]
        public string? EmergencyContact3Phone { get; set; }

        [JsonProperty("fields.Child's Address.postal_code")]
        public string? ChildAddressPostalCode { get; set; }

        [JsonProperty("fields.Dentist Address.postal_code")]
        public string? DentistAddressPostalCode { get; set; }

        [JsonProperty("fields.Pediatrician Address.street")]
        public string? PediatricianAddressStreet { get; set; }

        [JsonProperty("fields.Child's Address.state_province")]
        public string? ChildAddressState { get; set; }

        [JsonProperty("fields.Dentist Address.state_province")]
        public string? DentistAddressState { get; set; }

        [JsonProperty("fields.Medical Conditions / Allergies ")]
        public string? MedicalConditionsAllergies { get; set; }

        [JsonProperty("fields.Signature of parent or guardian")]
        public string? ParentGuardianSignature { get; set; }

        [JsonProperty("fields.Pediatrician Address.postal_code")]
        public string? PediatricianAddressPostalCode { get; set; }

        [JsonProperty("fields.Child's Dentist/Orthodontist.last")]
        public string? ChildDentistOrthodontistLastName { get; set; }

        [JsonProperty("fields.Child's Dentist/Orthodontist.first")]
        public string? ChildDentistOrthodontistFirstName { get; set; }

        // Parent references
        public int? Parent1Id { get; set; }
        public int? Parent2Id { get; set; }

        [ForeignKey("Parent1Id")]
        public ParentDetails? Parent1 { get; set; }

        [ForeignKey("Parent2Id")]
        public ParentDetails? Parent2 { get; set; }

        // Address reference
        public int ChildAddressId { get; set; }

        [ForeignKey("ChildAddressId")]
        public Address? ChildAddress { get; set; }

        // Emergency Contacts references
        public int? EmergencyContact1Id { get; set; }
        public int? EmergencyContact2Id { get; set; }
        public int? EmergencyContact3Id { get; set; }

        [ForeignKey("EmergencyContact1Id")]
        public EmergencyContact? EmergencyContact1 { get; set; }

        [ForeignKey("EmergencyContact2Id")]
        public EmergencyContact? EmergencyContact2 { get; set; }

        [ForeignKey("EmergencyContact3Id")]
        public EmergencyContact? EmergencyContact3 { get; set; }

        // Healthcare Provider reference
        public int? HealthcareProviderId { get; set; }

        [ForeignKey("HealthcareProviderId")]
        public HealthcareProvider? HealthcareProvider { get; set; }
    }

    public class ParentDetails
    {
        [Key]
        public int Id { get; set; }

        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? MobileNumber { get; set; }
        public string? WorkNumber { get; set; }
        public string? Email { get; set; }

        // Address reference
        public int AddressId { get; set; }

        [ForeignKey("AddressId")]
        public Address? Address { get; set; }

        // Navigation property for EmergencyContactForm
        public ICollection<EmergencyContactForm>? EmergencyContactForms { get; set; }
    }

    public class Address
    {
        [Key]
        public int Id { get; set; }

        [JsonProperty("street")]
        public string? Street { get; set; }

        [JsonProperty("city")]
        public string? City { get; set; }

        [JsonProperty("state_province")]
        public string? StateProvince { get; set; }

        [JsonProperty("postal_code")]
        public string? PostalCode { get; set; }

        // Navigation properties for ParentDetails and EmergencyContactForm
        public ICollection<ParentDetails>? Parents { get; set; }
        public ICollection<EmergencyContactForm>? EmergencyContactForms { get; set; }
    }

    public class EmergencyContact
    {
        [Key]
        public int Id { get; set; }

        [JsonProperty("fields.Emergency Contacts_1_Name")]
        public string? Name1 { get; set; }

        [JsonProperty("fields.Emergency Contacts_2_Name")]
        public string? Name2 { get; set; }

        [JsonProperty("fields.Emergency Contacts_3_Name")]
        public string? Name3 { get; set; }

        [JsonProperty("fields.Emergency Contacts_1_Phone")]
        public string? Phone1 { get; set; }

        [JsonProperty("fields.Emergency Contacts_2_Phone")]
        public string? Phone2 { get; set; }

        [JsonProperty("fields.Emergency Contacts_3_Phone")]
        public string? Phone3 { get; set; }

        // Navigation property for EmergencyContactForm
        public int EmergencyContactFormId { get; set; }

        [ForeignKey("EmergencyContactFormId")]
        public EmergencyContactForm? EmergencyContactForm { get; set; }
    }

    public class HealthcareProvider
    {
        [Key]
        public int Id { get; set; }

        [JsonProperty("fields.Child's Pediatrician.first")]
        public string? PediatricianFirstName { get; set; }

        [JsonProperty("fields.Child's Pediatrician.last")]
        public string? PediatricianLastName { get; set; }

        // Navigation property for EmergencyContactForm
        public int EmergencyContactFormId { get; set; }

        [ForeignKey("EmergencyContactFormId")]
        public EmergencyContactForm? EmergencyContactForm { get; set; }
    }
}
