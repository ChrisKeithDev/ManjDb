﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManjDb.DataModels
{
    public class ClassDesignation
    {
        public int? Id { get; set; }
        public string? Designation { get; set; }
    }
}
