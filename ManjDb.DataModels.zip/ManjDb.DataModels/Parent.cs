﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManjDb.DataModels
{
    public class Parent
    {
        [Key]
        public int? ParentId { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Email { get; set; }
        public string? Phone { get; set; }

        // Navigation property to represent the many-to-many relationship with Child
        public ICollection<Child>? Children { get; set; }
    }
}
