﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManjDb.DataModels
{
    public class DropoffPickupForm
    {
        [JsonProperty("child.name")]
        public string? ChildName { get; set; }

        [JsonProperty("The parent handbook has been updated to reflect the below policies. Please read them carefully. Thank you!")]
        public string? PolicyUpdateNote { get; set; }

        [JsonProperty("The undersigned hereby confirms that he/she has read and understands the Montessori Academy of New Jersey \"Late arrival policy\" and \"Circle drop off/pick up policy\", which have been updated for the 2023/2024 school year (and going forward).\nThis acknowledgement carries over year to year unless a change has been made by MANJ.")]
        public string? AcknowledgementText { get; set; }

        [JsonProperty("Signature of parent or guardian 1")]
        public string? ParentGuardian1Signature { get; set; }

        [JsonProperty("Signature of parent or guardian 2")]
        public string? ParentGuardian2Signature { get; set; }
    }
}
